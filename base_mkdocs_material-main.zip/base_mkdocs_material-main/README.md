# base_mkdocs_material
Modèle de base pour produire un site web avec MkDocs et le thème Material


> Le site est visible à l'adresse : [https://ericecmorlaix.github.io/base_mkdocs_material/](https://ericecmorlaix.github.io/base_mkdocs_material/)


> Un tutoriel est associée à cet exemple : [https://ericecmorlaix.github.io/adn-Tutoriel_site_web/](https://ericecmorlaix.github.io/adn-Tutoriel_site_web/)